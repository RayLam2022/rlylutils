import paddle
paddle.fluid.install_check.run_check()
import paddlehub
paddlehub.server_check()